package com.springmvc.pojo;

import java.util.List;

import com.springmvc.model.Product;
import com.springmvc.model.User;

public class PurchaseTable {

	User user;
	List<Product> list;
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public List<Product> getList() {
		return list;
	}
	public void setList(List<Product> list) {
		this.list = list;
	}
	@Override
	public String toString() {
		return "PurchaseTable [user=" + user + ", list=" + list + "]";
	}
	
	
}
