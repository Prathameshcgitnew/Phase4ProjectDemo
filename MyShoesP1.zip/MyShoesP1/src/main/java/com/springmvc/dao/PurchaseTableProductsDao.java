package com.springmvc.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.springmvc.model.PurchaseTableProducts;

@Repository
public class PurchaseTableProductsDao {
	
	@Autowired
	private HibernateTemplate hibernateTemplate;
	
	public HibernateTemplate getHibernateTemplate() {
		return hibernateTemplate;
	}

	public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
		this.hibernateTemplate = hibernateTemplate;
	}
	
	@Transactional
	public void saveDataInTable(PurchaseTableProducts purtD) {
		this.hibernateTemplate.save(purtD);
	}
	
	public List<PurchaseTableProducts> getAllproducts(){
		List<PurchaseTableProducts> list=this.hibernateTemplate.loadAll(PurchaseTableProducts.class);
	    return list;
	}
	
	@Transactional
	public void deleteAllpurchaseProduct(String myPrimaryKey) {
		PurchaseTableProducts pur=this.hibernateTemplate.get(PurchaseTableProducts.class, myPrimaryKey);
	    System.out.println(pur);
		this.hibernateTemplate.delete(pur);
	    return;
	
	}
	
	

}
