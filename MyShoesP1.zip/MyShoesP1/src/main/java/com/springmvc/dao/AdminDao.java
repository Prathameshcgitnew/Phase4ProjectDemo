package com.springmvc.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.springmvc.model.Admin;

@Repository
public class AdminDao {

	@Autowired
	private HibernateTemplate hibernateTemplate;
	
	public HibernateTemplate getHibernateTemplate() {
		return hibernateTemplate;
	}

	public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
		this.hibernateTemplate = hibernateTemplate;
	}

	public List<Admin> getAllAdmins() {
		// TODO Auto-generated method stub
		List<Admin> list=this.hibernateTemplate.loadAll(Admin.class);
	
		return list;
	}

	@Transactional
	public void deleteAdmin() {
		this.hibernateTemplate.deleteAll(getAllAdmins());	
	}
	
	@Transactional
	public void insertAdmin(Admin admin) {
		int id=(Integer)this.hibernateTemplate.save(admin);
	}
	
	
}
