package com.springmvc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;


import com.springmvc.dao.PurchaseTableProductsDao;

import com.springmvc.model.PurchaseTableProducts;

public class PurchaseTableProductsService {
	
	@Autowired
	private PurchaseTableProductsDao purchaseTableProductsDao;
	
	
	
	public PurchaseTableProductsService(PurchaseTableProductsDao purchaseTableProductDao) {
		super();
		this.purchaseTableProductsDao = purchaseTableProductDao;
	}



	public void saveallProductsinPurchaseTable(PurchaseTableProducts purchaseTableProducts) {
		this.purchaseTableProductsDao.saveDataInTable(purchaseTableProducts);
	}
	
	public List<PurchaseTableProducts> getAllProducts(){
		return this.purchaseTableProductsDao.getAllproducts();
	}
	
	public void deleteAllPurchasedProducts(String myPrimaryKey) {
		this.purchaseTableProductsDao.deleteAllpurchaseProduct(myPrimaryKey);
	}

}
