package com.springmvc.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springmvc.dao.AdminDao;
import com.springmvc.model.Admin;

@Service
public class AdminService {

	public AdminService(AdminDao adminDao) {
		super();
		this.adminDao = adminDao;
	}


	@Autowired 
	private AdminDao adminDao;
	
	
	public void enterAdminCredential(Admin admin) {
	     this.adminDao.insertAdmin(admin);
	}
}
