package com.springmvc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.springmvc.dao.UserDao;
import com.springmvc.model.User;

public class UserService {
    
	@Autowired
    private UserDao userDao;
	
	public void saveCreatedUser(User user) {
		this.userDao.insertUser(user);
	}

	public UserService(UserDao userDao) {
		super();
		this.userDao = userDao;
	}
    
	public List<User> presentAllUsers() {
		List<User> listUsers=this.userDao.getAllUsers();
		return listUsers;
	}
    
    
}
