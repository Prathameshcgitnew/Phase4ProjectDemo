package com.springmvc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.springmvc.dao.OrderDao;

import com.springmvc.model.Order1;

@Service
public class OrderService {
	
	@Autowired
	private OrderDao orderDao;
	
	public OrderService(OrderDao orderDao) {
		super();
		this.orderDao = orderDao;
	}

	
	public void enterOrderDetails(Order1 order) {
		this.orderDao.insertOrder(order);
	}
	
	public List<Order1> getAllOrdersForAllUsers() {
		return this.orderDao.getAllOrderRecords();
	}

	
}
