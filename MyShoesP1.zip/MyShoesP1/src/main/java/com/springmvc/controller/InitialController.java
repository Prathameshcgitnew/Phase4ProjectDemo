package com.springmvc.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.springmvc.model.Admin;



@Controller
public class InitialController {
	
	/*@Autowired
	private UserService userService;*/

	@RequestMapping("/")
	public String showForm(Model model1) {
		
		return "indexprev";
	}
	
	@RequestMapping("/UserLogin")
	public String getuserLogin() {
		return "userLogin";
	}
	
	@RequestMapping("/HomePage")
	public String gotoHomePage() {
		return "Home";
	}
	
	@RequestMapping(path="/AdminLogin",method=RequestMethod.POST)
	public String getadminLogin() {
		return "adminLogin";
	}
	
	
	@RequestMapping("/changepasswordProcess")
	public String getchangepasswordOfAdmin() {
		return "adminpasswordChange";
		
	}
	
	
	
	
	}

