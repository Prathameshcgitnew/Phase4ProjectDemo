package com.springmvc.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.springmvc.model.Order1;
import com.springmvc.model.User;
import com.springmvc.service.OrderService;
import com.springmvc.service.UserService;

@Controller
public class LinkPageController {
     
	@Autowired
	private UserService userService;
	
	@Autowired
	private OrderService orderService;
	
	@RequestMapping("/createUser")
	public String createUser() {
		return "createUser1";
	}
	
	@RequestMapping("/getAllUsers")
	public String getAllUsers(Model model) {
		
		List<User> list=this.userService.presentAllUsers();
		System.out.println(list);
		model.addAttribute("listofallUsers",list);
		return "getAllUsers1";
	}
	
	@RequestMapping("/purchaseHistory")
	public String purchaseHistory() {
	   return "purchaseHistory1";
	}
	
	@RequestMapping("purchaseReport")
	public String purchaseReport(Model model) {
		
		List<Order1> list=this.orderService.getAllOrdersForAllUsers();
		System.out.println(list);
		model.addAttribute("AllUserReport", list);
		return "purchaseReport1";
	}
}


