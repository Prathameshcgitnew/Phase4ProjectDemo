package com.springmvc.controller;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.springmvc.model.Order1;
import com.springmvc.model.PurchaseTableProducts;
import com.springmvc.model.User;
import com.springmvc.pojo.PurchaseTable;
import com.springmvc.service.OrderService;
import com.springmvc.service.ProductService;
import com.springmvc.service.PurchaseTableProductsService;

@Controller
public class ProductController {

	@Autowired	
	private ProductService productService;
	
	@Autowired
	private OrderService orderservice;

	@Autowired
	private PurchaseTableProductsService purchaseTableProductsService;

	List<PurchaseTableProducts> list;
	List<PurchaseTableProducts> list1=new ArrayList<PurchaseTableProducts>();

	@RequestMapping(path="/purchase0", method=RequestMethod.POST)
	public String productControllertest0(@ModelAttribute User user) {
		System.out.println("IN 0");
		list=this.purchaseTableProductsService.getAllProducts();
		list1.add(list.get(0));
		System.out.println(list1);
        return "GobackForBuy";
		/*	List<PurchaseTable> list=(List<PurchaseTable>)request.getAttribute("PurchaseTableData");
	    String username=user.getUsername();
	    PurchaseTable purT=(PurchaseTable)request.getAttribute("pur");
		System.out.println(list +"  "+username+" "+purT);*/
	}

	@RequestMapping(path="/purchase1", method=RequestMethod.POST)
	public String productControllertest1() {
		System.out.println("IN 1");
		list=this.purchaseTableProductsService.getAllProducts();
		list1.add(list.get(1));
		System.out.println(list1);
		return "GobackForBuy";
	}

	@RequestMapping(path="/purchase2", method=RequestMethod.POST)
	public String productControllertest2() {
		System.out.println("IN 2");
		list=this.purchaseTableProductsService.getAllProducts();
		list1.add(list.get(2));
		System.out.println(list1);
		return "GobackForBuy";
	}

	@RequestMapping(path="/purchase", method=RequestMethod.POST)
	public String buyTheProducts(Model model) {
		System.out.println("Buy The Products");
		LocalDate dt = LocalDate.parse(LocalDate.now().toString());
        System.out.println(dt);
        
        // Function call
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("YYYY-MM-dd");
        System.out.println(formatter.format(dt));
        String username=new String();
        Order1 orderTableInsert;
         int i=0;
        for(PurchaseTableProducts l:list1) {
        	orderTableInsert=new Order1();
        	
        	orderTableInsert.setUsername(l.getUsername());
        	orderTableInsert.setProductname(l.getProductname());
        	orderTableInsert.setCost(l.getCost());
        	orderTableInsert.setDate1(dt);
        	orderTableInsert.setCategory(l.getCategory());
        	this.orderservice.enterOrderDetails(orderTableInsert);
        	 
        
        }
        list=this.purchaseTableProductsService.getAllProducts();
        for(PurchaseTableProducts l:list) {
        	System.out.println(l.getMyPrimaryKey()+"****");
        this.purchaseTableProductsService.deleteAllPurchasedProducts(l.getMyPrimaryKey());
        }
        
        model.addAttribute("purchasedProducts", list1);
		return "purchasedProducts";
	}
	


}
