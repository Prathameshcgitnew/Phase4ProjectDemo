package com.springmvc.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.view.RedirectView;

@Controller
public class RedirectDemoController {
	
	@RequestMapping("/one")
	public String one() {
		System.out.println("Inside one");
		return "redirect:/two";
	}
	
	@RequestMapping("/two")
	public String two() {
		System.out.println("Inside two");
		return "redirect:/three";
	}
	
	@RequestMapping("/three")
	public RedirectView three() {
		RedirectView redirectview=new RedirectView();
		System.out.println("Inside Three");
		//redirectview.setUrl("https://www.google.com");
		redirectview.setUrl("enjoy");
		return redirectview;
	}
	
	@RequestMapping("/enjoy")
	public String four() {
		System.out.println("Inside four");
		return "redirect:/contact";
	}

}
