package com.springmvc.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.springmvc.model.Order1;
import com.springmvc.service.OrderService;

@Controller
public class LinktPageController {

	@Autowired
	private OrderService orderService;
	
	@RequestMapping(path="/history", method=RequestMethod.GET)
	public String getUserHistory(
			@ModelAttribute("username") String username,
			Model model) {
		List<Order1> list=this.orderService.getAllOrdersForAllUsers();
		System.out.println(list);
		System.out.println(username);
		List<Order1> list1=new ArrayList<Order1>();
		for(Order1 o:list) {
			if(o.getUsername().equals(username)) {
				list1.add(o);
			}
		}
		System.out.println("List1:"+list1);
		model.addAttribute("allOrders",list1);
		return "history1";
	}
	
}
