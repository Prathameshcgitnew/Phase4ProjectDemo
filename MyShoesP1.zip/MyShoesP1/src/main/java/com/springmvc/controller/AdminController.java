package com.springmvc.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.springmvc.dao.AdminDao;
import com.springmvc.dao.AdminDao;
import com.springmvc.model.Admin;
import com.springmvc.service.AdminService;

@Controller
public class AdminController {
	
	@Autowired
	private AdminDao adminDao;
	
	@Autowired
	private AdminService adminService;
	
	@RequestMapping("/adminLoginProcess")
    public String adminLoginValidation(@ModelAttribute Admin admin) {
		
		System.out.println(admin);
		List<Admin> list=adminDao.getAllAdmins();
		System.out.println(list);
		for(Admin a:list) {
		
			if(a.getUsername().equals(admin.getUsername()) && a.getPassword().equals(admin.getPassword())){
				
				System.out.println("Admin login successful");
	            return "LinkPage";
			}
				
			} 
			return "invalidCredential";	
		}
	
	@RequestMapping(path="/changeThePasswordCheck",method=RequestMethod.POST)
	public String changePasswordCheck(@RequestParam("username") String username,
			@RequestParam("password") String password,
			@RequestParam("confirmpassword") String confirmpassword,Model model
			)
	{
		System.out.println(username);
		System.out.println(password);
		System.out.println(confirmpassword);
		
		List<Admin> adminlist=adminDao.getAllAdmins();
		
		for(Admin a:adminlist) {
			
			if(a.getUsername().equals(username)  && password.equals(confirmpassword)) {
				
				this.adminDao.deleteAdmin();
				Admin newAdmin=new Admin();
			   // newAdmin.setId(1);
				newAdmin.setUsername(username);
				newAdmin.setPassword(confirmpassword);
				this.adminService.enterAdminCredential(newAdmin);
				//model.addAttribute("Header", "Please Enter new credentials");
				//model.addAttribute("Description", "Please Enter new credentials");
				return "adminLogin";
			}
		}
		
		return "AdminChangeInvalidCredential";
	}
	
		  
		  
	  }
	
	

