package com.springmvc.controller;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/first")
public class HomeController {

	
	@RequestMapping(path="/mypath" ,method=RequestMethod.GET)
	public void mypathMethod() {
		
	}
	
	
	
	
	
	
	@RequestMapping("/home")
	public String homepage(Model model) {
	 model.addAttribute("name", "Mahesh");
	 List<String> friends=new ArrayList<String>();
	 friends.add("Dev");
	 friends.add("Shiva");
	 model.addAttribute("f", friends);
     System.out.println("Inside Home Controller");
     return "index";
	}
	
	@RequestMapping("/about")
	public String aboutPage() {
		System.out.println("Inside about page");
		return "about";
	}
	
	@RequestMapping("/modelandviewtest")
	public ModelAndView help() {
		
		ModelAndView model =new ModelAndView();
		model.addObject("name", "Meheshwara");
		model.addObject("Id", 1234);
		LocalDateTime time=LocalDateTime.now();
		model.addObject("Time", time);
		model.setViewName("help");
		
		return model;
		
		
		
	}
	
}
