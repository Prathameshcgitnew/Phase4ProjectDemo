package com.springmvc.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.springmvc.model.Product;
import com.springmvc.model.PurchaseTableProducts;
import com.springmvc.model.User;
import com.springmvc.service.ProductService;
import com.springmvc.service.PurchaseTableProductsService;
import com.springmvc.service.UserService;

@Controller
public class UserController {

	@Autowired
	private UserService userService;

	@Autowired	
	private ProductService productService;
	
	@Autowired 
	private PurchaseTableProductsService purchaseTableProductsService;

	@RequestMapping("/SignInUser")
	public String signInUser() {
		return "userLogin";
	}

	@RequestMapping(path="/processCreateUser" , method=RequestMethod.POST)
	public String processCreateUser(@ModelAttribute User user) {

		user.setUsername(user.getFname()+user.getLname()+user.getId());
		user.setPassword(user.getId()+user.getLname()+user.getFname());
		System.out.println(user);
		this.userService.saveCreatedUser(user);
		return "UserCreatedSuccess";
	}

	@RequestMapping(path="/Login",method=RequestMethod.POST)
	public String userLoginProcess(@ModelAttribute User user,Model model) {

		System.out.println(user);
		List<User> listOfUsers=this.userService.presentAllUsers();
		System.out.println(listOfUsers);
		for(User usern:listOfUsers) {
			/*	System.out.println(usern.getUsername());
			System.out.println(user.getUsername());
			System.out.println(usern.getPassword());
			System.out.println(user.getPassword());*/
			if(usern.getUsername().equals(user.getUsername()) && usern.getPassword().equals(user.getPassword())){
				System.out.println("Userl login successful");
				List<Product> listOfProducts=this.productService.getListOfAllProducts();
				System.out.println(listOfProducts);
				PurchaseTableProducts purTProducts;
				for(Product l:listOfProducts) {
					purTProducts=new PurchaseTableProducts();
					purTProducts.setUsername(user.getUsername());
					purTProducts.setProductname(l.getProductname());
					purTProducts.setCost(l.getCost());
					purTProducts.setCategory(l.getCategory());
					purTProducts.setMyPrimaryKey(user.getUsername()+"_"+l.getProductname());
					this.purchaseTableProductsService.saveallProductsinPurchaseTable(purTProducts);
				}
				
				
				
				
				model.addAttribute("listOfAllProducts", listOfProducts);
				model.addAttribute("User", user);
				return "Home1";		
			}

		} 
		return "invalidCredentialNew";
	}
	//username=4_User_New, password=User_New_4
}
