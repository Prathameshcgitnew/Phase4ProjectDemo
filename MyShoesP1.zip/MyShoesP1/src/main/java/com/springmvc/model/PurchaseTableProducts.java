package com.springmvc.model;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class PurchaseTableProducts {
	
	
	
	private String username;
	
	
	private String productname;
	
	
	private int cost;
	
	private String category;
	
	@Id
	private String myPrimaryKey;

	public String getMyPrimaryKey() {
		return myPrimaryKey;
	}

	public void setMyPrimaryKey(String myPrimaryKey) {
		this.myPrimaryKey = myPrimaryKey;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getProductname() {
		return productname;
	}

	public void setProductname(String productname) {
		this.productname = productname;
	}

	public int getCost() {
		return cost;
	}

	public void setCost(int cost) {
		this.cost = cost;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}
	
	@Override
	public String toString() {
		return "PurchaseTableProducts [username=" + username + ", productname=" + productname + ", cost=" + cost
				+ ", category=" + category + "]";
	}

	
}
