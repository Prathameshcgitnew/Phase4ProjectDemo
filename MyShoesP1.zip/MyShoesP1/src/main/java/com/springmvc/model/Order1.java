package com.springmvc.model;



import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Order1 {
    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    public int id;
    
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}

	public String username;
	public String productname;
	public int cost;
	public LocalDate date1;
	public LocalDate getDate1() {
		return date1;
	}
	public void setDate1(LocalDate date1) {
		this.date1 = date1;
	}

	public String category;
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getProductname() {
		return productname;
	}
	public void setProductname(String productname) {
		this.productname = productname;
	}
	public int getCost() {
		return cost;
	}
	public void setCost(int i) {
		this.cost = i;
	}
	
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	@Override
	public String toString() {
		return "Order [id=" + id + ", username=" + username + ", productname=" + productname + ", cost=" + cost
				+ ", date1=" + date1 + ", category=" + category + "]";
	}
	
	
	
	
	
	
	
	
}
